package CS355.LWJGL;

public interface CS355LWJGLController {

    void render();

    void resizeGL();

    void update();

    void updateKeyboard();
    
}
